new DataTable("#dataPegawai", {
    layout: {
        topStart: {
            buttons: ["copy", "csv", "excel", "pdf", "print"],
        },
    },
});